<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashbaordController extends Controller
{
     public function show()
    {
		//echo 666;die();
        return view('Auth.login');
        
    }
    public function loadDashboard()
    {
//		echo 666;die();
        return view('Dashboard.welcome');
        
    }
}

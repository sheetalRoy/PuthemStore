<!DOCTYPE html>
<html>

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <title>iCamp</title>
        <!--font-awesome.min.css-->
        

        <!--bootstrap.min.css-->
        <link rel="stylesheet" href="{{ asset('bootstrap/css/bootstrap.min.css') }}" type="text/css">
       
        
        <!-- Our Custom CSS -->
    
        <!-- Font Awesome JS -->
        
        <style>
            .wrapper {
                display: flex;
                width: 100%;
                align-items: stretch;
            }
            .wrapper {
                display: flex;
                align-items: stretch;
            }
            #sidebar {
                min-width: 250px;
                max-width: 250px;
            }
            #sidebar.active {
                margin-left: -250px;
            }
            #sidebar {
                min-width: 250px;
                max-width: 250px;
                min-height: 100vh;
            }
            a[data-toggle="collapse"] {
                position: relative;
            }
            .dropdown-toggle::after {
                display: block;
                position: absolute;
                top: 50%;
                right: 20px;
                transform: translateY(-50%);
            }
            @media (max-width: 768px) {
                #sidebar {
                    margin-left: -250px;
                }
                #sidebar.active {
                    margin-left: 0;
                }
            }
            
            body {
                font-family: 'Poppins', sans-serif;
                background: #fafafa;
            }
            p {
                font-family: 'Poppins', sans-serif;
                font-size: 1.1em;
                font-weight: 300;
                line-height: 1.7em;
                color: #999;
            }
            a, a:hover, a:focus {
                color: inherit;
                text-decoration: none;
                transition: all 0.3s;
            }
            #sidebar {
                /* don't forget to add all the previously mentioned styles here too */
                background: #fff;
                color: #000;
                transition: all 0.3s;
                border:1px solid #ccc;
            }
            #sidebar .sidebar-header {
                padding: 20px;
                background: #fff;
            }
            #sidebar ul.components {
                padding: 20px 0;
                border-bottom: 1px solid #47748b;
            }
            #sidebar ul p {
                color: #fff;
                padding: 10px;
            }
            #sidebar ul li a {
                padding: 10px;
                font-size: 1.1em;
                display: block;
            }
            #sidebar ul li a:hover {
                color: #7386D5;
                background: #fff;
            }
            #sidebar ul li.active > a, a[aria-expanded="true"] {
                color: #fff;
                background: #6d7fcc;
            }
            ul ul a {
                font-size: 0.9em !important;
                padding-left: 30px !important;
                background: #6d7fcc;
            }
        </style>
    </head>

    <body>
        <div class="header" style="width: 100%;height: 100px;background-color: blue;">
            Header Area
        </div>
        <!--Header area end -->
        <div class="wrapper">
            <!-- Sidebar -->
            <nav id="sidebar">
                <div class="sidebar-header">
                    <h3>Bootstrap Sidebar</h3>
                </div>

                <ul class="list-unstyled components">
                    <p>Dummy Heading</p>
                    <li class="active">
                        <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Home</a>
                        <ul class="collapse list-unstyled" id="homeSubmenu">
                            <li>
                                <a href="#">Home 1</a>
                            </li>
                            <li>
                                <a href="#">Home 2</a>
                            </li>
                            <li>
                                <a href="#">Home 3</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">About</a>
                    </li>
                    <li>
                        <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Pages</a>
                        <ul class="collapse list-unstyled" id="pageSubmenu">
                            <li>
                                <a href="#">Page 1</a>
                            </li>
                            <li>
                                <a href="#">Page 2</a>
                            </li>
                            <li>
                                <a href="#">Page 3</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#" onclick="">Create Vehicle demo</a>
                    </li>
                    <li>
                        <a id="Create Vehicle" class="sub-menu-expand">Create Vehicle</a>
                    </li>
                </ul>
            </nav>
            <div id="content" style="width: 100%;">
                <button type="button" id="sidebarCollapse" class="btn">
                    <i class="fa fa-bars"></i>
                    <span></span>
                </button>
<!--                {#<nav class="navbar navbar-expand-lg navbar-light bg-light">
                    <div class="container-fluid">
                    </div>
                </nav>#}-->
                <!--axaj load area -->
                <div id="loadFormArea" style="">
                    <!--dashboard area -->
                    <div class="container-fluid" style="width: 100%;padding: 10px;background-color:#0257c0;height: 50px;float: left; ">
                        <p>Vehicle Management</p>
                    </div>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-3" style="background-color: yellow;height: 250px;">Create Vehicle</div>
                            <div class="col-md-3" style="background-color: gray;height: 250px;">2</div>
                            <div class="col-md-3" style="background-color: yellow;height: 250px;">3</div>
                            <div class="col-md-3" style="background-color: gray;height: 250px;"></div>
                            <div class="col-md-3"></div>
                            <div class="col-md-3"></div>
                            <div class="col-md-3"></div>
                            <div class="col-md-3">8</div>
                        </div>
                    </div>
                </div>
            </div>
                    
        </div>

        <!-- jquery link -->
        <script src="{{ asset('bundles/assets/js/jquery.min.js') }}"></script>         

        <!--bootstrap.min.js-->
        <script type="text/javascript" src="{{ asset('bundles/assets/bootstrap/js/bootstrap.min.js') }}"></script>
        
        <script type="text/javascript" src="{{ asset('bundles/acmedemo/js/auth.js') }}"></script>
        <script type="text/javascript" src="{{ asset('bundles/acmedemo/js/common.js') }}"></script>
       
        <!-- Popper.JS -->
        
        
        
        <script>
                            $(document).ready(function () {
                                $('#sidebarCollapse').on('click', function () {
                                    $('#sidebar').toggleClass('active');
                                });
                            });
        function load(url) {
    var loadArea = $('#loadFormArea');
    $.ajax({
        url: url,
        complete: function () {
            disabledButton(false);
        },
        beforeSend: function () {
            disabledButton(true);
        },
        contentType: false,
        processData: false,
        type: 'POST',
        dataType: 'json',
        success: function (response) {
            
                $(loadArea).empty().append(response.html['html']);
                
        }, error: function () {
        }
    });
}
        </script>
    </body>

</html>

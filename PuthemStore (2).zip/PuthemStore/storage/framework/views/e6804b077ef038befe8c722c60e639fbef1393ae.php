<!doctype html>
<html class="no-js" lang="en">
    <head>
        <!-- META DATA -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->				

        <!-- TITLE OF SITE -->
        <title>Puthem</title>

        <!-- for title img 
                <link rel="shortcut icon"  type="image/icon"  href="assets/images/logo/favicon.png"/>
        -->

        <!--font-awesome.min.css-->
        <!--        <link rel="stylesheet" href="<?php echo e(asset('bundles/assets/fonts/font-awesome/css/font-awesome.min.css')); ?>">
                <link rel="stylesheet" href="<?php echo e(asset('bundles/assets/fonts/font-awesome/css/font-awesome.css')); ?>">
        
                bootstrap.min.css-->
        <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" type="text/css">
        <link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet">
        <style>

        </style>

    </head>
    <body>
        <div class="container-fluid indexPageContainer">
            <div class="row" >
                <div class="loginBoxLeft col-xs-12 col-sm-6" style="">
                    <p style="font-size: 16px;font-weight: bold;color:#fff;padding-top: 30%;">Puthem Store</p>
                </div>
                <div class="loginBoxRight col-xs-12 col-sm-6">

                    <br/>

                    <div id="" class="formContainer" style="">
                        <div class="" style="padding: 5px 0px 0px 0px;">
                            <p style="font-size: 16px;font-weight: bold;">Please Sign In</p>
                        </div>
                        <form class="" id="formLogin" name="frmLogin" method="post" action="">
                            <div class="form-group">
                                <input type="hidden" name="ranStr" id="ranStr" value="" />

                                <label class="input-label" for="txtuid">Username</label>
                                <input type="text" class="form-control textbox" placeholder="type here your username" name="txtuid" id="txtuid" autocomplete="off" autofocus required="required">
                                <div class="bar"></div>
                            </div>
                            <div class="form-group">
                                <label class="input-label" for="txtpasswd">Password</label>
                                <input type="password" class="form-control textbox" placeholder="type here your password" name="txtpasswd" id="txtpasswd" onfocus="checkCaps(this, event);" required="required">
                                <span style="display: none;" id="caps-warning">Caps is on!<span class="bottomindicator"></span></span>
                                <div class="bar"></div>
                            </div>

                            <div class="form-group">    
                                <a type="button" class="btn btn-primary btnBlue" href="<?php echo e(url('/dashboard')); ?>">Sign In</a>
                                <input type="hidden" id="baseUrl" value=""/>
                                <input type="hidden" name="token" value="" />
                                <input type="hidden" name="resetpwd" id="resetpwd" value="Reset Password" />
                                <!--<input type="submit" class="btn btn-primary btnBlue" id="login" name="login" value="Sign In" onclick="return jFunctSubmit();">-->

                            </div>
                            <div class="form-group">        

                                <a id="forgetPwdLink" style="color: #000;" href="">Forgot Password?</a>

                            </div>

                        </form>
                    </div>
                </div> <!--right container end-->

            </div>     <!--row end -->           

        </div>  <!--indexcontainer end -->

        <!-- jquery link -->
        <script src="<?php echo e(asset('bundles/assets/js/jquery.min.js')); ?>"></script>         

        <!--bootstrap.min.js-->
        <script type="text/javascript" src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
    </body>

</html>